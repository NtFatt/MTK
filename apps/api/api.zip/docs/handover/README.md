# Handover & Spec (API)

Tài liệu phục vụ bàn giao và thiết kế.

## Files
- **Hadilao_Software_Design_Spec_v4_Enterprise.docx**: Bản thiết kế chủ chốt (Enterprise).
- **Hadilao_Project_Progress_Handover_v11_20260209.docx**: Handover/tiến độ (ngày 2026-02-09).
- Các file `*_v5/v9` giữ lại để tra cứu lịch sử.

## Quick usage
- Xem trạng thái hiện tại + việc cần làm tiếp: mở Handover v11.
- So khớp yêu cầu và kiến trúc: mở Spec v4.
